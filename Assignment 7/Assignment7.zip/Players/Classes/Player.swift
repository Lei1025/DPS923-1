//
//  Player.swift
//  Players
//
//  Created by Bakytzhan Apetov on 2017-03-22.
//  Copyright © 2017 School of ICT, Seneca College. All rights reserved.
//

import Foundation
import CoreData

@objc(Player)
class Player: NSManagedObject { }
